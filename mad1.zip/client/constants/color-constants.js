
const COLORS = {
    WHITE: "#fff",
    BLACK: "#000"
}

export { COLORS };