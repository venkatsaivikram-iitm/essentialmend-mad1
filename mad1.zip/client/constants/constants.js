const REQUEST_STATUS = {
    PENDING: "pending",
    GRANTED: "granted"
};


export { REQUEST_STATUS };