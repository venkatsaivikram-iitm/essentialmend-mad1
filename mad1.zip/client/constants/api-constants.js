
const API_RESPONSE = {
    SUCCESS: "success",
    FAILURE: "failure"
}

export { API_RESPONSE };