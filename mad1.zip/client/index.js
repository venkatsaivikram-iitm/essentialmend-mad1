import ConfigHolder from "./utils/config-holder";

ConfigHolder.config = window.__config__;