import uuid

def generateID ():
    ID = uuid.uuid4()
    
    return str(ID)